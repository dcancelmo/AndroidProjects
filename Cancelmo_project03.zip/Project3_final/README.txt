Daniel Cancelmo
dcancelm@u.rochester.edu
CSC 214 - Android Mobile App Development
Professor St Jacques
TA: Alan Beadle
Project 03
May 3, 2017
ReadMe File

I affirm that I did not give or receive any unauthorized help on this project, and that all work herein is my own.

Code description:
My database stores all of the necessary items for an "InfoItem" object. It is used to sotre the custom entries users can create.A single ListDisplayActivity is used to host all of the different list fragments. On a tablet it displays both the list and the details fragment for the selected infoitem rather than opening a dialog (which gives basic info and an option to go to a details activity with the fragment) like it does on phones. 
A clicking sound effect is played on choosing the category and the UR song "The Genesee" sung by the UR Yellow Jackets is played from the MainActivity (this is done to fulfill requirements, I personally hate when apps make unnecessary noises). Also added is an embedded map and the ability to take pictures as well as video. These were also added to fulfill the project requirements and would not actually be in a finished app that I would consider appropriate to publish.

This app was developed for Android version 7.1.1 API 25 and texted on the Nexus 6 with 1440x2560 resolution and x86 CPU.