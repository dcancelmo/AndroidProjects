Daniel Cancelmo
dcancelm@u.rochester.edu
CSC 214 - Android Mobile App Development
Professor St Jacques
TA: Alan Beadle
Assignment 07
April 4, 2017
ReadMe File

I did not collaborate with anyone and all work within this submission is my own.

This assignment was to create an app that utilized databases to store data. The user uses menus to change activities to an activity to enter data for a new course that when entered will be displayed in the recycler view of the main activity.

This app was developed for Android version 7.1.1 API 25 and texted on the Nexus 6 with 1440x2560 resolution and x86 CPU.