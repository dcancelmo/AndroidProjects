Daniel Cancelmo
dcancelm@u.rochester.edu
CSC 214 - Android Mobile App Development
Professor St Jacques
TA: Alan Beadle
Assignment 04
February 21, 2017
ReadMe File

This assignment was to create an app with a main activity that displayed an initial default string and buttons to create two new activities. FontActivity allows the user to change the font in ways such as bold, italic, underlined, color, and size. MessageActivity allows the user to change the content of the string displayed. The purpose was to practice creating new activities, passing data between activities, response codes, orientation locking, persisting data, and fragments. The okay buttons would pass the data and the cancel buttons would finish the activity without returning data. MessageActivity utilized a fragment.

This app was developed for Android version 7.1.1 API 25 and texted on the Nexus 6 with 1440x2560 resolution and x86 CPU.