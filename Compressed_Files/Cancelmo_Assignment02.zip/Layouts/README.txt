Daniel Cancelmo
dcancelm@u.rochester.edu
CSC 214 - Android Mobile App Development
Professor St Jacques
TA: Alan Beadle
Assignment 02
February 04, 2017
ReadMe File

This assignment was to use linear and relative layouts to create an app with three buttons and one textview. Two buttons needed to display toast messages and one button effect the textview by decrementing the value shown (which starts at 100). I added a relative layout inside the root relative layout that contains a linear layout and a textview. The linear layout shows the three buttons in a row. The first two say ‘Dev Name’ and ’TA Name’ and when clicked show ‘Daniel Cancelmo’ and ‘Alan Beadle’ respectively. The third button says ‘Decrement’ and when clicked lowers the value shown in the textview by one.
This app was developed for Android version 7.1.1 API 25 and texted on the Nexus 6 with 1440x2560 resolution and x86 CPU.