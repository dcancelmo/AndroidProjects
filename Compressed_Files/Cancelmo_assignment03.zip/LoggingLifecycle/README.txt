Daniel Cancelmo
dcancelm@u.rochester.edu
CSC 214 - Android Mobile App Development
Professor St Jacques
TA: Alan Beadle
Assignment 03
February 12, 2017
ReadMe File

This assignment was to create an app that utilizes logs, gain familiarity with the activity lifecycle, ImageViews and ImageButtons, orientations, and state persistence. I overrode each of the lifecycle methods to print a log each time they are called. I created two orientations, portrait and landscape, with different layouts. Both have an ImageView, ImageButton, and TextView. I added two drawables using pictures taken from Google images representing travel. The ImageButton toggles between the two images. The Textview displays how many times the device has been rotated. The current image and the number of rotations persists throughout the lifecycle using a Bundle.

This app was developed for Android version 7.1.1 API 25 and texted on the Nexus 6 with 1440x2560 resolution and x86 CPU.