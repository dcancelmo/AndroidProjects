Daniel Cancelmo
dcancelm@u.rochester.edu
CSC 214 - Android Mobile App Development
Professor St Jacques
TA: Alan Beadle
Assignment 09
April 25, 2017
ReadMe File

I did not collaborate with anyone and all work within this submission is my own.

AsyncTask
Whichever task is clicked first will finish and then display the result and then be overwritten by the second clicked asynctask (when done) regardless of speed. It is based on order of being created.
HandlerThread
The code task executes based on which finishes first so the latter task will override the prior.

The purpose of this application is to implement asynctask and handlers to complete (small) time consuming tasks.

I used AsyncTask to implement fetching the image because it should not take an extended period of time to fetch an image.

This app was developed for Android version 7.1.1 API 25 and texted on the Nexus 6 with 1440x2560 resolution and x86 CPU.