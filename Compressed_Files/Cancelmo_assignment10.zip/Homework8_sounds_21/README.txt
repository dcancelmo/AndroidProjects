Daniel Cancelmo
dcancelm@u.rochester.edu
CSC 214 - Android Mobile App Development
Professor St Jacques
TA: Alan Beadle
Assignment 10 - Originally 08
May 2, 2017
ReadMe File

I did not collaborate with anyone and all work within this submission is my own.

I fixed the issues given by the TA for the original submission. The original assignment was assignment 8.
It now displays the default and pressed now have different states. The shapes of the modern and old buttons are now different. I also added some more comments.

This assignment was to create an app that would play audio files. It must retain the fragments so that playback is not interupted. It must also make use of mater-detail interface when rotated to landscape. The app must use a custom style using custom colors and 'buttons' for each item of the recyclerview. The styles must also be different for pre and post Android API 21.

Testing was done using emulators of Nexus 6: One running API 25 and the other API 19.