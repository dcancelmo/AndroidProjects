Daniel Cancelmo
dcancelm@u.rochester.edu
CSC 214 - Android Mobile App Development
Professor St Jacques
TA: Alan Beadle
Assignment 06
February 24, 2017
ReadMe File

I did not collaborate with anyone and all work within this submission is my own.

This assignment was to create an app that utilized ListView and RecyclerView and used ViewPager to travel between them. It also used a DialogFragment to display an AlertDialog of the data relevant to the objects being displayed that is too long for the List/Recycler Views (ie a course description).
RecyclerView has a red background and ListView a Yellow background. (R for Red and Recycler- L for Lemon and List)

The benefits of using a RecyclerView (RV) over a ListView(LV) are that RV incorporates all of the 'best practicies' of LV into itself. RV is not fixed to one layout, can update items in the list, and is more efficient in recycling old items.

This app was developed for Android version 7.1.1 API 25 and texted on the Nexus 6 with 1440x2560 resolution and x86 CPU.