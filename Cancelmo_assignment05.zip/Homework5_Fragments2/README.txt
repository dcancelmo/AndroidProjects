Daniel Cancelmo
dcancelm@u.rochester.edu
CSC 214 - Android Mobile App Development
Professor St Jacques
TA: Alan Beadle
Assignment 05
February 21, 2017
ReadMe File

I did not collaborate with anyone and all work within this submission is my own.

This assignment was to create an app with a main activity that displayed two fragments and a center part that has widgets directly in the activity. The user passes text form the main activity to the top fragment to display. The user then can also send text from the top fragment to the bottom fragment to display.

This app was developed for Android version 7.1.1 API 25 and texted on the Nexus 6 with 1440x2560 resolution and x86 CPU.