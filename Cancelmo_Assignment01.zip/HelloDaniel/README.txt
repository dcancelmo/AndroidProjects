Daniel Cancelmo
dcancelm@u.rochester.edu
CSC 214 - Android Mobile App Development
Professor St Jacques
TA: Alan Beadle
Assignment 01
January 26, 2017

The assignment was to become familair with Android Studio and download all necessary software. A project was created and the app_name in strings.xml was altered to put a space in between Hello and my name (Daniel). The string being displayed in activity_hello_daniel.xml was changed from "Hello World!" to "Hello, Daniel Cancelmo!". The assignment was specifically to hard code this rather than store the sting in strings.xml.
