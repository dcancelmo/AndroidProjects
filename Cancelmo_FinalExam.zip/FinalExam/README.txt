Daniel Cancelmo
dcancelm@u.rochester.edu
CSC 214 - Android Mobile App Development
Professor St Jacques
TA: Alan Beadle
Final Exam
May 13, 2017
ReadMe File

HONOR PLEDGE: “I affirm that I will not give or receive any unauthorized help on this exam, and that all work will be my own.”

This is my submission for the final exam practical. Starter code for the final was provided by Professor Bobby StJacques.

This app was developed for Android version 7.1.1 API 25 and texted on the Nexus 6 with 1440x2560 resolution and x86 CPU.